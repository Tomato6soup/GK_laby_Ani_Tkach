var teapotModel = {
    vertexPositions: new Float32Array([
      // Base (square)
      -10, 0, -10,
       10, 0, -10,
       10, 0,  10,
      -10, 0,  10,
      // Apex
       0, 15, 0
    ]),
  
    vertexNormals: new Float32Array([
      // Normals for the base
      0, -1, 0,
      0, -1, 0,
      0, -1, 0,
      0, -1, 0,
      // Normals for the apex (roughly outward)
      0, 1, 0
    ]),
  
    vertexTextureCoords: new Float32Array([
      0, 0,
      1, 0,
      1, 1,
      0, 1,
      0.5, 0.5
    ]),
  
    indices: new Uint16Array([
      // Base
      0, 1, 2,
      0, 2, 3,
      // Sides
      0, 1, 4,
      1, 2, 4,
      2, 3, 4,
      3, 0, 4
    ])
  };
  