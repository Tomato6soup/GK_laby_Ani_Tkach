function pyramid() {
    const s = 0.5;

    // 6 trójkątów = 18 wierzchołków
    const positions = [
        // Podstawa (dwa trójkąty)
        -s, 0, -s,  s, 0, -s,  s, 0,  s,
        -s, 0, -s,  s, 0,  s, -s, 0,  s,

        // Ściana 1
        -s, 0, -s,  s, 0, -s,  0, s * 1.5, 0,

        // Ściana 2
         s, 0, -s,  s, 0,  s,  0, s * 1.5, 0,

        // Ściana 3
         s, 0,  s, -s, 0,  s,  0, s * 1.5, 0,

        // Ściana 4
        -s, 0,  s, -s, 0, -s,  0, s * 1.5, 0,
    ];

    const normals = [
        // Podstawa (płasko w dół)
        0, -1, 0,  0, -1, 0,  0, -1, 0,
        0, -1, 0,  0, -1, 0,  0, -1, 0,

        // Ściana 1
        0, 0.707, 0.707,  0, 0.707, 0.707,  0, 0.707, 0.707,

        // Ściana 2
        -0.707, 0.707, 0,  -0.707, 0.707, 0,  -0.707, 0.707, 0,

        // Ściana 3
        0, 0.707, -0.707,  0, 0.707, -0.707,  0, 0.707, -0.707,

        // Ściana 4
        0.707, 0.707, 0,  0.707, 0.707, 0,  0.707, 0.707, 0
    ];

    // Indeksy od 0 do 17 (czyli po kolei, bo nie ma współdzielonych wierzchołków)
    const indices = new Uint8Array([...Array(18).keys()]);

    return {
        vertexPositions: new Float32Array(positions),
        vertexNormals: new Float32Array(normals),
        indices: indices
    };
}
function createPyramid() {
    return pyramid();
}
